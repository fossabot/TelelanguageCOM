<div id="sidebar" class="col-md-4" role="complementary">
    <aside class="widget-area">
       <?php $sidebar = esc_attr( get_post_meta(get_the_ID(), 'thm_slidebar',true )); ?>
        <?php 

        if($sidebar == 1){
          dynamic_sidebar('sidebar');
        }
        elseif ($sidebar == 2) {
          dynamic_sidebar('eventsidebar');
        }
        elseif ($sidebar == 3) {
          dynamic_sidebar('coursesidebar');
        } else {
           dynamic_sidebar('sidebar');
          } ?>
    </aside>
</div> <!-- #sidebar -->

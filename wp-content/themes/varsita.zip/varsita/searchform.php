<form role="form" method="get" id="searchform" action="<?php echo esc_url(home_url( '/' )); ?>" >
    <input type="text" value="" name="s" id="s" class="form-control" placeholder="<?php _e('Search . . . . .','themeum') ?>" autocomplete="off" />
    <button class="btn btn-style btn-search"><i class="fa fa-search"></i></button>
</form>